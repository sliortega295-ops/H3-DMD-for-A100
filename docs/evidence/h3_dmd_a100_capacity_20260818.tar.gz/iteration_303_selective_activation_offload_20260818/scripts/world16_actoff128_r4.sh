#!/usr/bin/env bash
set -euo pipefail
RUN=/share/project/shuchenweng/yongyan_liu/H3-DMD-for-A100_20260818_v2/artifacts/runs/h3_world16_shared_backbone_onecycle_20260818_r4_sac_seg8_actoff128
ROOT=/tmp/lyy-experiments/H3-DMD-for-A100/V2/source
PY=/share/project/shuchenweng/yongyan_liu/DMD-System_assets/lightx2v_minimax_dmd_20260817/env/bin/python
NODE_RANK=${NODE_RANK:?set NODE_RANK}
mkdir -p "$RUN/train_output"
date -Is > "$RUN/start.node${NODE_RANK}.txt"
cat /sys/fs/cgroup/memory.events > "$RUN/memory.events.before.node${NODE_RANK}"
export PYTHONUNBUFFERED=1
export PYTHONPATH=/tmp/lyy-experiments/H3-DMD-for-A100/V2/local_site:$ROOT:$ROOT/third_party/LightX2V:$ROOT/third_party/LightX2V/lightx2v_train
export USE_TF=0
export USE_TORCH=1
export TRANSFORMERS_NO_TF=1
export H3_FLASH_ATTN3_LOCAL_PATH=/share/project/shuchenweng/yongyan_liu/DMD-System_assets/lightx2v_minimax_dmd_20260817/hf_home/hub/models--kernels-community--flash-attn3/snapshots/acb0f42e6901d3e9effa8a83bd32bc2bf0cfdfc2/build/torch210-cxx11-cu128-x86_64-linux
export HF_HOME=/share/project/shuchenweng/yongyan_liu/DMD-System_assets/lightx2v_minimax_dmd_20260817/hf_home
export HF_HUB_CACHE=$HF_HOME/hub
export HF_HUB_OFFLINE=1
export TRANSFORMERS_OFFLINE=1
export H3_ATTN_BACKEND=_flash_3_hub
export H3_ACTIVATION_CHECKPOINT_SEGMENT=8
export H3_ACTIVATION_OFFLOAD=1
export H3_ACTIVATION_OFFLOAD_MIN_BYTES=134217728
export H3_ACTIVATION_OFFLOAD_PIN_MEMORY=1
export H3_BENCHMARK_SEED=42
export H3_MAX_ITERS=1
export H3_SAVE_EVERY=0
export MINIMAX_H3_MODEL_PATH=/share/project/shuchenweng/yongyan_liu/DMD-System_assets/lightx2v_minimax_dmd_20260817/models/MiniMax-H3-train
export H3_PROMPT_CACHE=/share/project/shuchenweng/yongyan_liu/DMD-System_assets/lightx2v_minimax_dmd_20260817/prompt_cache/minimax_h3_prompt_cache_96
export H3_OUTPUT_DIR=$RUN/train_output
set +e
timeout 7200 "$PY" -m torch.distributed.run --nnodes=2 --nproc_per_node=8 --node_rank="$NODE_RANK" --master_addr=172.24.211.148 --master_port=29652 --module h3_a100.entrypoint --config "$ROOT/configs/minimax_h3_t2av_dmd_a100_world16.yaml"
S=$?
set -e
printf '%s\n' "$S" > "$RUN/exit.code.node${NODE_RANK}"
date -Is > "$RUN/stop.node${NODE_RANK}.txt"
cat /sys/fs/cgroup/memory.events > "$RUN/memory.events.after.node${NODE_RANK}"
exit "$S"
