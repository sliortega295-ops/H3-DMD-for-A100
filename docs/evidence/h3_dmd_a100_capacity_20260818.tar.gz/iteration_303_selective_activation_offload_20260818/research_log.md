## Iteration 303 — world16 selective activation offload

### Milestone / Gate
H3-DMD-for-A100 primary world16 capacity gate after segmented-checkpoint
candidate. The segment=8 candidate had already failed; this iteration tested
the preregistered next mechanism only.

### Question
Can thresholded saved-tensor CPU offload (first >=128 MiB, then >=64 MiB)
remove enough grad-path activation pressure for the exact world16 one-cycle
MiniMax-H3 workload to pass without changing the compute contract?

### Hypothesis / Refutation
Large saved tensors dominate the first Student backward peak; moving them to
pinned CPU should admit the one-cycle update. Refuted if both thresholds fail
at the same first checkpoint-recompute workspace allocation.

### Allowed changes
Only opt-in saved-tensor hooks around the Student/Fake grad path. No loss,
optimizer, sample, RNG, precision, FSDP topology, application call count, or
checkpoint segment change.

### Runs
- `h3_world16_shared_backbone_onecycle_20260818_r4_sac_seg8_actoff128`
- `h3_world16_shared_backbone_onecycle_20260818_r5_sac_seg8_actoff64`

### Measured results
r4 and r5 both failed CUDA OOM at the first Student backward checkpoint
recompute in the FFN LoRA projection. r5 rank0 offloaded 9 saved tensors /
3,651,056,640 bytes; the failure remained a 2.02 GiB live allocation with
about 37.87 GiB allocated and 74–134 MiB driver free. cgroup OOM delta was 0.

### Correctness / Performance
Correctness: NOT_RUN because capacity failed before completion.
Performance: NOT_RUN; no Full5 timer was started.

### Interpretation
Thresholded saved-tensor offload was active, but the failing allocation is a
checkpoint-recompute FFN/LoRA workspace rather than a retained saved tensor.
The 64 MiB threshold did not change the failure point. This is a bounded
negative result for this mechanism, not evidence that all CPU activation
offload designs are impossible.

### Gate status
`SELECTIVE_ACTIVATION_OFFLOAD_128`: FAIL.
`SELECTIVE_ACTIVATION_OFFLOAD_64`: FAIL.
`PRIMARY_CAPACITY_PASS`: NOT_RUN.

### Next highest-value question
Can a semantics-preserving H3 context/sequence-parallel implementation split
the full token/activation working set? The pinned LightX2V path has generic SP
helpers but no MiniMax-H3 integration; do not substitute broadcast or duplicate
samples. CP/SP2 is therefore NOT_RUN pending a separate design/approval.
